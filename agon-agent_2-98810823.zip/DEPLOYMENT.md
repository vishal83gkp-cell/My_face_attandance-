# 🚀 Face Recognition Attendance System - Deployment Guide

## Live Demo
The application is already deployed and running!

---

## Deployment Options

### 1️⃣ Vercel (Recommended)

**Step 1: Install Vercel CLI**
```bash
npm install -g vercel
```

**Step 2: Login to Vercel**
```bash
vercel login
```

**Step 3: Deploy**
```bash
vercel
```

**Step 4: Production Deploy**
```bash
vercel --prod
```

---

### 2️⃣ Netlify

**Step 1: Build Project**
```bash
npm run build
```

**Step 2: Install Netlify CLI**
```bash
npm install -g netlify-cli
```

**Step 3: Deploy**
```bash
netlify deploy --prod --dir=dist
```

---

### 3️⃣ GitHub Pages

**Step 1: Add to package.json**
```json
{
  "homepage": "https://YOUR_USERNAME.github.io/face-attendance",
  "scripts": {
    "predeploy": "npm run build",
    "deploy": "gh-pages -d dist"
  }
}
```

**Step 2: Install gh-pages**
```bash
npm install gh-pages --save-dev
```

**Step 3: Update vite.config.ts**
```typescript
export default defineConfig({
  base: '/face-attendance/',
  // ... rest of config
})
```

**Step 4: Deploy**
```bash
npm run deploy
```

---

### 4️⃣ Render.com (Free)

1. Go to https://render.com
2. Create account
3. Click "New" → "Static Site"
4. Connect GitHub repository
5. Build Command: `npm run build`
6. Publish Directory: `dist`
7. Click "Create Static Site"

---

### 5️⃣ Railway.app

1. Go to https://railway.app
2. Login with GitHub
3. "New Project" → "Deploy from GitHub repo"
4. Select repository
5. Auto-deploy ho jaayega

---

## 🔧 Environment Setup

### For Production:

1. **Create `.env` file** (if using backend)
```env
VITE_API_URL=your_api_url
VITE_FACE_API_MODEL_URL=https://cdn.jsdelivr.net/npm/@vladmandic/face-api@1.7.12/model
```

2. **Update face-api.js models**
Models already CDN se load hote hain, no extra setup needed!

---

## 📱 Run Locally

```bash
# Clone repository
git clone YOUR_REPO_URL

# Go to project folder
cd face-attendance-system

# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

---

## 🔐 Demo Credentials

**Admin Login:**
- Email: `admin@school.edu`
- Password: (any password)

**Student Login:**
- Email: `john@student.edu` (or any demo student email)
- Password: (any password)

---

## 📋 Features Checklist

✅ Face Recognition Attendance
✅ Manual Attendance Backup
✅ Student Management
✅ Class Management
✅ Attendance Reports
✅ PDF/Excel Export
✅ Dark Mode UI
✅ Mobile Responsive
✅ Real-time Face Detection
✅ Auto Face Registration

---

## 🛠️ Tech Stack

- **Frontend:** React 19 + TypeScript + Vite
- **Styling:** Tailwind CSS v4
- **Face Recognition:** face-api.js
- **Charts:** Recharts
- **Export:** jsPDF + xlsx
- **Icons:** Lucide React
- **Animations:** Framer Motion

---

## 📞 Support

Agar koi problem aaye toh:
1. Browser console check karein (F12)
2. Camera permissions allow karein
3. HTTPS required for camera access (localhost exception)

---

## 🌐 Important Notes

1. **Camera Access:** HTTPS required (except localhost)
2. **Face Models:** Auto-load from CDN (~50MB)
3. **Browser Support:** Chrome, Firefox, Edge (Modern browsers)
4. **Mobile:** Works on mobile browsers

---

Made with ❤️ for easy attendance management!
