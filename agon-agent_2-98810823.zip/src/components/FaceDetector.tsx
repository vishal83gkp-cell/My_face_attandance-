import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, XCircle, AlertCircle, Camera, UserCheck, RefreshCw } from 'lucide-react';
import { WebcamCapture } from './WebcamCapture';
import { loadModels, detectFace, getFaceDescriptor, findMatchingStudent, drawFaceDetection } from '../lib/faceRecognition';
import { Student } from '../types';

interface FaceDetectorProps {
  students: Student[];
  onMatch: (studentId: string, confidence: number, photo: string, descriptor?: Float32Array) => void;
  onNoMatch?: (photo: string, descriptor?: Float32Array) => void;
  mode?: 'attendance' | 'registration';
  onRegisterFace?: (studentId: string, descriptor: Float32Array, photo: string) => void;
}

interface DetectionState {
  status: 'idle' | 'detecting' | 'detected' | 'matched' | 'no-match' | 'error';
  message: string;
  matchedStudent?: Student;
  confidence?: number;
}

export const FaceDetector: React.FC<FaceDetectorProps> = ({
  students,
  onMatch,
  onNoMatch,
  mode = 'attendance',
  onRegisterFace,
}) => {
  const [modelsLoaded, setModelsLoaded] = useState(false);
  const [detectionState, setDetectionState] = useState<DetectionState>({
    status: 'idle',
    message: 'Position your face in the frame and click Capture',
  });
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [currentDescriptor, setCurrentDescriptor] = useState<Float32Array | null>(null);
  const [faceDetectedInVideo, setFaceDetectedInVideo] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const lastDescriptorRef = useRef<Float32Array | null>(null);

  useEffect(() => {
    const initModels = async () => {
      setDetectionState({ status: 'detecting', message: 'Loading face detection models...' });
      const loaded = await loadModels();
      setModelsLoaded(loaded);
      if (loaded) {
        setDetectionState({ status: 'idle', message: 'Position your face in the frame and click Capture' });
      } else {
        setDetectionState({
          status: 'error',
          message: 'Failed to load face detection models. Please refresh the page.',
        });
      }
    };
    initModels();
  }, []);

  const handleFrame = useCallback(async (video: HTMLVideoElement) => {
    if (!modelsLoaded || detectionState.status === 'matched') return;

    try {
      const detection = await detectFace(video);
      
      if (detection && canvasRef.current) {
        drawFaceDetection(canvasRef.current, video, detection);
        setFaceDetectedInVideo(true);
        
        // Get descriptor in real-time for smoother experience
        const descriptor = await getFaceDescriptor(video);
        if (descriptor) {
          lastDescriptorRef.current = descriptor;
        }
      } else {
        setFaceDetectedInVideo(false);
      }
    } catch (error) {
      console.error('Frame processing error:', error);
    }
  }, [modelsLoaded, detectionState.status]);

  const handleCapture = useCallback(async (imageSrc: string) => {
    if (!modelsLoaded) {
      setDetectionState({ status: 'error', message: 'Models not loaded yet. Please wait...' });
      return;
    }

    setCapturedPhoto(imageSrc);
    setDetectionState({ status: 'detecting', message: 'Analyzing face...' });

    // Create image element from captured photo
    const img = new window.Image();
    img.src = imageSrc;
    
    img.onload = async () => {
      try {
        const descriptor = await getFaceDescriptor(img);
        
        if (!descriptor) {
          setDetectionState({ status: 'no-match', message: 'No face detected. Please try again with better lighting.' });
          onNoMatch?.(imageSrc);
          return;
        }

        setCurrentDescriptor(descriptor);

        if (mode === 'attendance') {
          // Find matching student
          const studentsWithDescriptors = students.filter(s => s.faceDescriptor);
          
          if (studentsWithDescriptors.length === 0) {
            // No registered faces - allow manual selection
            setDetectionState({ 
              status: 'no-match', 
              message: 'No registered faces. Select a student below to register & mark attendance.' 
            });
            onNoMatch?.(imageSrc, descriptor);
            return;
          }

          const match = findMatchingStudent(descriptor, studentsWithDescriptors as Array<{ id: string; faceDescriptor?: Float32Array }>);
          
          if (match) {
            const matchedStudent = students.find(s => s.id === match.studentId);
            setDetectionState({
              status: 'matched',
              message: `Welcome, ${matchedStudent?.name}!`,
              matchedStudent,
              confidence: match.confidence,
            });
            onMatch(match.studentId, match.confidence, imageSrc);
          } else {
            // Face detected but not recognized
            setDetectionState({ 
              status: 'no-match', 
              message: 'Face not recognized. Select student below to register.' 
            });
            onNoMatch?.(imageSrc, descriptor);
          }
        } else {
          // Registration mode
          setDetectionState({ status: 'matched', message: 'Face captured successfully!' });
          onMatch('', 100, imageSrc, descriptor);
        }
      } catch (error) {
        console.error('Face processing error:', error);
        setDetectionState({ status: 'error', message: 'Error processing face. Please try again.' });
      }
    };

    img.onerror = () => {
      setDetectionState({ status: 'error', message: 'Failed to process image.' });
    };
  }, [students, mode, onMatch, onNoMatch, modelsLoaded]);

  const resetDetection = useCallback(() => {
    setDetectionState({ status: 'idle', message: 'Position your face in the frame and click Capture' });
    setCapturedPhoto(null);
    setCurrentDescriptor(null);
    setFaceDetectedInVideo(false);
  }, []);

  return (
    <div className="w-full">
      {/* Status indicator */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className={`flex items-center gap-3 p-4 rounded-xl mb-4 ${
          detectionState.status === 'matched' ? 'bg-green-500/10 border border-green-500/20' :
          detectionState.status === 'no-match' ? 'bg-yellow-500/10 border border-yellow-500/20' :
          detectionState.status === 'detected' ? 'bg-blue-500/10 border border-blue-500/20' :
          detectionState.status === 'error' ? 'bg-red-500/10 border border-red-500/20' :
          'bg-slate-800/50 border border-slate-700'
        }`}
      >
        {detectionState.status === 'matched' && <CheckCircle className="w-5 h-5 text-green-400" />}
        {detectionState.status === 'no-match' && <AlertCircle className="w-5 h-5 text-yellow-400" />}
        {detectionState.status === 'detected' && <UserCheck className="w-5 h-5 text-blue-400" />}
        {detectionState.status === 'error' && <XCircle className="w-5 h-5 text-red-400" />}
        {(detectionState.status === 'idle' || detectionState.status === 'detecting') && (
          <AlertCircle className="w-5 h-5 text-slate-400" />
        )}
        <div className="flex-1">
          <p className={`text-sm font-medium ${
            detectionState.status === 'matched' ? 'text-green-400' :
            detectionState.status === 'no-match' ? 'text-yellow-400' :
            detectionState.status === 'detected' ? 'text-blue-400' :
            detectionState.status === 'error' ? 'text-red-400' :
            'text-slate-300'
          }`}>
            {detectionState.message}
          </p>
          {detectionState.confidence && (
            <p className="text-xs text-slate-400 mt-1">
              Confidence: {detectionState.confidence}%
            </p>
          )}
        </div>
        {(detectionState.status === 'matched' || detectionState.status === 'no-match' || detectionState.status === 'error') && (
          <button
            onClick={resetDetection}
            className="flex items-center gap-1 px-3 py-1 text-xs bg-slate-700 hover:bg-slate-600 rounded-lg transition-colors"
          >
            <RefreshCw className="w-3 h-3" />
            Reset
          </button>
        )}
      </motion.div>

      {/* Face detected indicator */}
      {faceDetectedInVideo && !capturedPhoto && (
        <div className="flex items-center gap-2 p-2 mb-4 bg-green-500/10 border border-green-500/20 rounded-lg">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
          <span className="text-sm text-green-400">Face detected - Ready to capture!</span>
        </div>
      )}

      {/* Camera or captured photo */}
      <div className="relative">
        {!capturedPhoto ? (
          <div className="relative">
            <WebcamCapture
              onCapture={handleCapture}
              showControls={modelsLoaded && detectionState.status !== 'matched'}
              onFrame={handleFrame}
            />
            <canvas
              ref={canvasRef}
              className="absolute inset-0 pointer-events-none"
              style={{ width: '100%', height: '100%' }}
            />
          </div>
        ) : (
          <div className="relative aspect-video max-w-2xl mx-auto rounded-2xl overflow-hidden">
            <img src={capturedPhoto} alt="Captured" className="w-full h-full object-cover" />
            {detectionState.matchedStudent && (
              <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-green-400 to-emerald-600 flex items-center justify-center">
                    <CheckCircle className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-white font-semibold">{detectionState.matchedStudent.name}</p>
                    <p className="text-sm text-slate-300">{detectionState.matchedStudent.rollNo}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Loading models indicator */}
      {!modelsLoaded && (
        <div className="flex items-center justify-center gap-3 p-4 mt-4 bg-slate-800/50 rounded-xl">
          <div className="w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-sm text-slate-400">Loading face detection models...</p>
        </div>
      )}
    </div>
  );
};
