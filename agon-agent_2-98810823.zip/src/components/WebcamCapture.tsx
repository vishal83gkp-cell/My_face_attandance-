import React, { useRef, useCallback, useEffect, useState } from 'react';
import Webcam from 'react-webcam';
import { Camera, RefreshCw, X } from 'lucide-react';
import { motion } from 'framer-motion';

interface WebcamCaptureProps {
  onCapture: (imageSrc: string) => void;
  onClose?: () => void;
  showControls?: boolean;
  autoCapture?: boolean;
  onFrame?: (video: HTMLVideoElement) => void;
}

export const WebcamCapture: React.FC<WebcamCaptureProps> = ({
  onCapture,
  onClose,
  showControls = true,
  autoCapture = false,
  onFrame,
}) => {
  const webcamRef = useRef<Webcam>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isReady, setIsReady] = useState(false);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [error, setError] = useState<string | null>(null);

  const videoConstraints = {
    width: { ideal: 640 },
    height: { ideal: 480 },
    facingMode,
  };

  const handleUserMedia = useCallback(() => {
    setIsReady(true);
    setError(null);
  }, []);

  const handleUserMediaError = useCallback(() => {
    setError('Unable to access camera. Please check permissions.');
  }, []);

  const capture = useCallback(() => {
    const imageSrc = webcamRef.current?.getScreenshot();
    if (imageSrc) {
      onCapture(imageSrc);
    }
  }, [onCapture]);

  const toggleCamera = useCallback(() => {
    setFacingMode(prev => prev === 'user' ? 'environment' : 'user');
  }, []);

  // Process frames for face detection
  useEffect(() => {
    if (!onFrame || !isReady) return;

    const interval = setInterval(() => {
      if (webcamRef.current?.video) {
        onFrame(webcamRef.current.video);
      }
    }, 100);

    return () => clearInterval(interval);
  }, [onFrame, isReady]);

  return (
    <div className="relative w-full max-w-2xl mx-auto">
      {/* Error state */}
      {error && (
        <div className="aspect-video bg-slate-800 rounded-2xl flex flex-col items-center justify-center text-slate-400">
          <Camera className="w-16 h-16 mb-4 opacity-50" />
          <p className="text-lg font-medium">Camera Unavailable</p>
          <p className="text-sm mt-2">{error}</p>
          <button
            onClick={() => setError(null)}
            className="mt-4 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
          >
            Try Again
          </button>
        </div>
      )}

      {/* Webcam view */}
      {!error && (
        <div className="relative aspect-video bg-slate-900 rounded-2xl overflow-hidden">
          <Webcam
            ref={webcamRef}
            audio={false}
            screenshotFormat="image/jpeg"
            videoConstraints={videoConstraints}
            onUserMedia={handleUserMedia}
            onUserMediaError={handleUserMediaError}
            className="w-full h-full object-cover"
            mirrored={facingMode === 'user'}
          />
          
          {/* Overlay canvas for face detection */}
          <canvas
            ref={canvasRef}
            className="absolute inset-0 w-full h-full pointer-events-none"
          />
          
          {/* Scanning overlay */}
          {!isReady && (
            <div className="absolute inset-0 flex items-center justify-center bg-slate-900/80">
              <div className="text-center">
                <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
                <p className="text-slate-400">Initializing camera...</p>
              </div>
            </div>
          )}
          
          {/* Face guide overlay */}
          {isReady && (
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64">
                <svg viewBox="0 0 200 200" className="w-full h-full">
                  {/* Face outline guide */}
                  <ellipse
                    cx="100"
                    cy="100"
                    rx="70"
                    ry="90"
                    fill="none"
                    stroke="rgba(59, 130, 246, 0.5)"
                    strokeWidth="2"
                    strokeDasharray="10 5"
                    className="animate-pulse"
                  />
                </svg>
              </div>
            </div>
          )}
          
          {/* Close button */}
          {onClose && (
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-2 bg-black/50 hover:bg-black/70 rounded-full transition-colors"
            >
              <X className="w-5 h-5 text-white" />
            </button>
          )}
        </div>
      )}

      {/* Controls */}
      {showControls && isReady && !error && (
        <div className="flex items-center justify-center gap-4 mt-6">
          <button
            onClick={toggleCamera}
            className="p-3 bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors"
            title="Switch Camera"
          >
            <RefreshCw className="w-5 h-5 text-slate-300" />
          </button>
          
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={capture}
            className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl font-medium shadow-lg shadow-blue-500/25 hover:shadow-blue-500/40 transition-shadow"
          >
            <Camera className="w-5 h-5" />
            Capture Photo
          </motion.button>
        </div>
      )}
    </div>
  );
};
