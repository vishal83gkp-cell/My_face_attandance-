import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { Student, Class, AttendanceRecord, Notification } from '../types';
import { 
  getStudents, saveStudents,
  getClasses, saveClasses,
  getAttendance, saveAttendance,
  getNotifications, saveNotifications,
  getDarkMode, saveDarkMode
} from '../lib/storage';
import { generateId, getDateKey } from '../lib/utils';

interface AppContextType {
  students: Student[];
  classes: Class[];
  attendance: AttendanceRecord[];
  notifications: Notification[];
  darkMode: boolean;
  
  // Student actions
  addStudent: (student: Omit<Student, 'id' | 'createdAt'>) => Student;
  updateStudent: (id: string, updates: Partial<Student>) => void;
  deleteStudent: (id: string) => void;
  
  // Class actions
  addClass: (classItem: Omit<Class, 'id' | 'createdAt' | 'updatedAt' | 'studentCount'>) => Class;
  updateClass: (id: string, updates: Partial<Class>) => void;
  deleteClass: (id: string) => void;
  
  // Attendance actions
  markAttendance: (record: Omit<AttendanceRecord, 'id'>) => void;
  getTodayAttendance: (classId?: string) => AttendanceRecord[];
  getStudentAttendance: (studentId: string) => AttendanceRecord[];
  getClassAttendance: (classId: string, date?: string) => AttendanceRecord[];
  
  // Notification actions
  addNotification: (type: Notification['type'], message: string) => void;
  removeNotification: (id: string) => void;
  clearNotifications: () => void;
  
  // Dark mode
  toggleDarkMode: () => void;
  
  // Stats
  getStats: () => AppStats;
}

interface AppStats {
  totalStudents: number;
  totalClasses: number;
  todayAttendance: number;
  todayPercentage: number;
  weeklyAttendance: number;
  monthlyAttendance: number;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [students, setStudents] = useState<Student[]>([]);
  const [classes, setClasses] = useState<Class[]>([]);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [darkMode, setDarkMode] = useState(false);

  // Load data on mount
  useEffect(() => {
    setStudents(getStudents());
    setClasses(getClasses());
    setAttendance(getAttendance());
    setNotifications(getNotifications());
    setDarkMode(getDarkMode());
  }, []);

  // Apply dark mode to document
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    saveDarkMode(darkMode);
  }, [darkMode]);

  // Student actions
  const addStudent = useCallback((studentData: Omit<Student, 'id' | 'createdAt'>): Student => {
    const newStudent: Student = {
      ...studentData,
      id: generateId(),
      createdAt: new Date().toISOString(),
    };
    const updatedStudents = [...students, newStudent];
    setStudents(updatedStudents);
    saveStudents(updatedStudents);
    
    // Update class student count
    const classToUpdate = classes.find(c => c.id === newStudent.classId);
    if (classToUpdate) {
      const updatedClasses = classes.map(c => 
        c.id === newStudent.classId 
          ? { ...c, studentCount: c.studentCount + 1 }
          : c
      );
      setClasses(updatedClasses);
      saveClasses(updatedClasses);
    }
    
    return newStudent;
  }, [students, classes]);

  const updateStudent = useCallback((id: string, updates: Partial<Student>) => {
    const updatedStudents = students.map(s => 
      s.id === id ? { ...s, ...updates } : s
    );
    setStudents(updatedStudents);
    saveStudents(updatedStudents);
  }, [students]);

  const deleteStudent = useCallback((id: string) => {
    const student = students.find(s => s.id === id);
    const updatedStudents = students.filter(s => s.id !== id);
    setStudents(updatedStudents);
    saveStudents(updatedStudents);
    
    // Update class student count
    if (student?.classId) {
      const updatedClasses = classes.map(c => 
        c.id === student.classId 
          ? { ...c, studentCount: Math.max(0, c.studentCount - 1) }
          : c
      );
      setClasses(updatedClasses);
      saveClasses(updatedClasses);
    }
  }, [students, classes]);

  // Class actions
  const addClass = useCallback((classData: Omit<Class, 'id' | 'createdAt' | 'updatedAt' | 'studentCount'>): Class => {
    const newClass: Class = {
      ...classData,
      id: generateId(),
      studentCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    const updatedClasses = [...classes, newClass];
    setClasses(updatedClasses);
    saveClasses(updatedClasses);
    return newClass;
  }, [classes]);

  const updateClass = useCallback((id: string, updates: Partial<Class>) => {
    const updatedClasses = classes.map(c => 
      c.id === id ? { ...c, ...updates, updatedAt: new Date().toISOString() } : c
    );
    setClasses(updatedClasses);
    saveClasses(updatedClasses);
  }, [classes]);

  const deleteClass = useCallback((id: string) => {
    const updatedClasses = classes.filter(c => c.id !== id);
    setClasses(updatedClasses);
    saveClasses(updatedClasses);
    
    // Remove students from this class
    const updatedStudents = students.map(s => 
      s.classId === id ? { ...s, classId: '' } : s
    );
    setStudents(updatedStudents);
    saveStudents(updatedStudents);
  }, [classes, students]);

  // Attendance actions
  const markAttendance = useCallback((recordData: Omit<AttendanceRecord, 'id'>) => {
    const today = getDateKey();
    
    // Check for duplicate
    const existing = attendance.find(
      a => a.studentId === recordData.studentId && 
           a.date === recordData.date && 
           a.classId === recordData.classId
    );
    
    if (existing) return;
    
    const newRecord: AttendanceRecord = {
      ...recordData,
      id: generateId(),
    };
    
    const updatedAttendance = [...attendance, newRecord];
    setAttendance(updatedAttendance);
    saveAttendance(updatedAttendance);
  }, [attendance]);

  const getTodayAttendance = useCallback((classId?: string): AttendanceRecord[] => {
    const today = getDateKey();
    return attendance.filter(a => 
      a.date === today && (!classId || a.classId === classId)
    );
  }, [attendance]);

  const getStudentAttendance = useCallback((studentId: string): AttendanceRecord[] => {
    return attendance.filter(a => a.studentId === studentId);
  }, [attendance]);

  const getClassAttendance = useCallback((classId: string, date?: string): AttendanceRecord[] => {
    return attendance.filter(a => 
      a.classId === classId && (!date || a.date === date)
    );
  }, [attendance]);

  // Notification actions
  const addNotification = useCallback((type: Notification['type'], message: string) => {
    const newNotification: Notification = {
      id: generateId(),
      type,
      message,
      timestamp: new Date().toISOString(),
    };
    const updatedNotifications = [newNotification, ...notifications].slice(0, 10);
    setNotifications(updatedNotifications);
    saveNotifications(updatedNotifications);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
      removeNotification(newNotification.id);
    }, 5000);
  }, [notifications]);

  const removeNotification = useCallback((id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  const clearNotifications = useCallback(() => {
    setNotifications([]);
    saveNotifications([]);
  }, []);

  // Dark mode toggle
  const toggleDarkMode = useCallback(() => {
    setDarkMode(prev => !prev);
  }, []);

  // Stats
  const getStats = useCallback((): AppStats => {
    const today = getDateKey();
    const todayRecords = attendance.filter(a => a.date === today);
    const presentToday = todayRecords.filter(a => a.status === 'present' || a.status === 'late').length;
    
    // Calculate weekly attendance
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    const weeklyRecords = attendance.filter(a => new Date(a.date) >= weekAgo);
    const weeklyPresent = weeklyRecords.filter(a => a.status === 'present' || a.status === 'late').length;
    
    // Calculate monthly attendance
    const monthAgo = new Date();
    monthAgo.setMonth(monthAgo.getMonth() - 1);
    const monthlyRecords = attendance.filter(a => new Date(a.date) >= monthAgo);
    const monthlyPresent = monthlyRecords.filter(a => a.status === 'present' || a.status === 'late').length;
    
    return {
      totalStudents: students.length,
      totalClasses: classes.length,
      todayAttendance: presentToday,
      todayPercentage: students.length > 0 ? Math.round((presentToday / students.length) * 100) : 0,
      weeklyAttendance: weeklyPresent,
      monthlyAttendance: monthlyPresent,
    };
  }, [students, classes, attendance]);

  return (
    <AppContext.Provider value={{
      students,
      classes,
      attendance,
      notifications,
      darkMode,
      addStudent,
      updateStudent,
      deleteStudent,
      addClass,
      updateClass,
      deleteClass,
      markAttendance,
      getTodayAttendance,
      getStudentAttendance,
      getClassAttendance,
      addNotification,
      removeNotification,
      clearNotifications,
      toggleDarkMode,
      getStats,
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = (): AppContextType => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
