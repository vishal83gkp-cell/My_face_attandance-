import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, UserRole, Student, Admin } from '../types';
import { 
  getCurrentUser, 
  saveCurrentUser, 
  getStudents, 
  getAdmins,
  initializeDemoData
} from '../lib/storage';
import { generateId } from '../lib/utils';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string, role: UserRole) => Promise<{ success: boolean; message: string }>;
  signup: (data: SignupData) => Promise<{ success: boolean; message: string }>;
  logout: () => void;
}

interface SignupData {
  email: string;
  password: string;
  name: string;
  role: UserRole;
  rollNo?: string;
  classId?: string;
  age?: number;
  phone?: string;
  address?: string;
  employeeId?: string;
  department?: string;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Initialize demo data on first load
    initializeDemoData();
    
    // Check for existing session
    const savedUser = getCurrentUser();
    if (savedUser) {
      setUser(savedUser);
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string, role: UserRole): Promise<{ success: boolean; message: string }> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // In a real app, you'd validate against a backend
    // For demo, we check against stored users
    if (role === 'admin') {
      const admins = getAdmins();
      const admin = admins.find(a => a.email.toLowerCase() === email.toLowerCase());
      if (admin) {
        setUser(admin);
        saveCurrentUser(admin);
        return { success: true, message: 'Login successful!' };
      }
      // Demo admin login
      if (email.toLowerCase() === 'admin@school.edu') {
        const demoAdmin: Admin = {
          id: generateId(),
          email,
          name: 'Dr. Sarah Johnson',
          role: 'admin',
          employeeId: 'EMP001',
          department: 'Computer Science',
          createdAt: new Date().toISOString(),
        };
        setUser(demoAdmin);
        saveCurrentUser(demoAdmin);
        return { success: true, message: 'Login successful!' };
      }
    } else {
      const students = getStudents();
      const student = students.find(s => s.email.toLowerCase() === email.toLowerCase());
      if (student) {
        setUser(student);
        saveCurrentUser(student);
        return { success: true, message: 'Login successful!' };
      }
    }
    
    return { success: false, message: 'Invalid credentials. Please try again.' };
  };

  const signup = async (data: SignupData): Promise<{ success: boolean; message: string }> => {
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // Check if email already exists
    const students = getStudents();
    const admins = getAdmins();
    
    if (students.some(s => s.email.toLowerCase() === data.email.toLowerCase()) ||
        admins.some(a => a.email.toLowerCase() === data.email.toLowerCase())) {
      return { success: false, message: 'Email already registered.' };
    }
    
    if (data.role === 'student') {
      const newStudent: Student = {
        id: generateId(),
        email: data.email,
        name: data.name,
        role: 'student',
        rollNo: data.rollNo || `STU${Date.now()}`,
        classId: data.classId || '',
        age: data.age || 18,
        phone: data.phone,
        address: data.address,
        createdAt: new Date().toISOString(),
      };
      setUser(newStudent);
      saveCurrentUser(newStudent);
    } else {
      const newAdmin: Admin = {
        id: generateId(),
        email: data.email,
        name: data.name,
        role: 'admin',
        employeeId: data.employeeId || `EMP${Date.now()}`,
        department: data.department,
        createdAt: new Date().toISOString(),
      };
      setUser(newAdmin);
      saveCurrentUser(newAdmin);
    }
    
    return { success: true, message: 'Account created successfully!' };
  };

  const logout = () => {
    setUser(null);
    saveCurrentUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, isAuthenticated: !!user, isLoading, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
