// Export utilities for PDF and Excel

import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import { AttendanceRecord, Student, Class } from '../types';
import { format } from 'date-fns';

interface ExportData {
  studentName: string;
  rollNo: string;
  className: string;
  status: string;
  time?: string;
  method?: string;
  confidence?: number;
}

export const exportToPDF = (
  data: ExportData[],
  title: string,
  date: string,
  className?: string
): void => {
  const doc = new jsPDF();
  
  // Header
  doc.setFillColor(15, 23, 42);
  doc.rect(0, 0, 210, 40, 'F');
  
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(24);
  doc.setFont('helvetica', 'bold');
  doc.text('Attendance Report', 105, 18, { align: 'center' });
  
  doc.setFontSize(12);
  doc.setFont('helvetica', 'normal');
  doc.text(title, 105, 28, { align: 'center' });
  
  // Reset text color
  doc.setTextColor(0, 0, 0);
  
  // Info section
  doc.setFontSize(10);
  doc.text(`Date: ${date}`, 14, 50);
  if (className) {
    doc.text(`Class: ${className}`, 14, 58);
  }
  doc.text(`Generated: ${format(new Date(), 'PPpp')}`, 14, className ? 66 : 58);
  
  // Statistics
  const present = data.filter(d => d.status === 'Present').length;
  const absent = data.filter(d => d.status === 'Absent').length;
  const late = data.filter(d => d.status === 'Late').length;
  const total = data.length;
  const percentage = total > 0 ? ((present + late) / total * 100).toFixed(1) : '0';
  
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text('Summary:', 14, className ? 80 : 72);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.text(`Total Students: ${total}`, 14, className ? 88 : 80);
  doc.text(`Present: ${present}  |  Absent: ${absent}  |  Late: ${late}`, 14, className ? 96 : 88);
  doc.text(`Attendance Rate: ${percentage}%`, 14, className ? 104 : 96);
  
  // Table
  const tableData = data.map((item, index) => [
    (index + 1).toString(),
    item.studentName,
    item.rollNo,
    item.className,
    item.status,
    item.time || '-',
    item.method || '-',
  ]);
  
  autoTable(doc, {
    startY: className ? 115 : 107,
    head: [['#', 'Student Name', 'Roll No', 'Class', 'Status', 'Time', 'Method']],
    body: tableData,
    theme: 'grid',
    headStyles: {
      fillColor: [59, 130, 246],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252],
    },
    styles: {
      fontSize: 9,
      cellPadding: 4,
    },
    columnStyles: {
      0: { cellWidth: 10 },
      1: { cellWidth: 40 },
      2: { cellWidth: 25 },
      3: { cellWidth: 35 },
      4: { cellWidth: 25 },
      5: { cellWidth: 25 },
      6: { cellWidth: 25 },
    },
  });
  
  // Footer
  const pageCount = doc.getNumberOfPages();
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(128, 128, 128);
    doc.text(
      `Page ${i} of ${pageCount} | Face Recognition Attendance System`,
      105,
      doc.internal.pageSize.height - 10,
      { align: 'center' }
    );
  }
  
  doc.save(`attendance_${date.replace(/\//g, '-')}.pdf`);
};

export const exportToExcel = (
  data: ExportData[],
  filename: string
): void => {
  const worksheet = XLSX.utils.json_to_sheet(
    data.map((item, index) => ({
      'S.No': index + 1,
      'Student Name': item.studentName,
      'Roll No': item.rollNo,
      'Class': item.className,
      'Status': item.status,
      'Time': item.time || '-',
      'Method': item.method || '-',
      'Confidence': item.confidence ? `${item.confidence}%` : '-',
    }))
  );
  
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Attendance');
  
  // Auto-size columns
  const colWidths = [
    { wch: 6 },  // S.No
    { wch: 25 }, // Student Name
    { wch: 12 }, // Roll No
    { wch: 20 }, // Class
    { wch: 10 }, // Status
    { wch: 12 }, // Time
    { wch: 10 }, // Method
    { wch: 12 }, // Confidence
  ];
  worksheet['!cols'] = colWidths;
  
  XLSX.writeFile(workbook, `${filename}.xlsx`);
};

export const prepareAttendanceExportData = (
  records: AttendanceRecord[],
  students: Student[],
  classes: Class[],
  date?: string
): ExportData[] => {
  // If no records, return all students as absent
  if (records.length === 0 && students.length > 0) {
    return students.map(student => {
      const classInfo = classes.find(c => c.id === student.classId);
      return {
        studentName: student.name,
        rollNo: student.rollNo,
        className: classInfo ? `${classInfo.name} - ${classInfo.section}` : 'Unknown',
        status: 'Absent',
      };
    });
  }
  
  return records.map(record => ({
    studentName: record.studentName,
    rollNo: record.rollNo,
    className: record.className,
    status: record.status.charAt(0).toUpperCase() + record.status.slice(1),
    time: record.time,
    method: record.method === 'face' ? 'Face Recognition' : 'Manual',
    confidence: record.confidence,
  }));
};
