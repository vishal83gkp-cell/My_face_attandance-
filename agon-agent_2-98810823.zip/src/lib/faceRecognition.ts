// Face Recognition utilities using face-api.js

import * as faceapi from 'face-api.js';

const MODEL_URL = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api@1.7.12/model';

let modelsLoaded = false;

export const loadModels = async (): Promise<boolean> => {
  if (modelsLoaded) return true;
  
  try {
    await Promise.all([
      faceapi.nets.ssdMobilenetv1.loadFromUri(MODEL_URL),
      faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL),
      faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL),
      faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
    ]);
    modelsLoaded = true;
    console.log('Face-api models loaded successfully');
    return true;
  } catch (error) {
    console.error('Error loading face-api models:', error);
    return false;
  }
};

export const detectFace = async (
  video: HTMLVideoElement
): Promise<faceapi.FaceDetection | null> => {
  if (!modelsLoaded) {
    await loadModels();
  }
  
  try {
    const detection = await faceapi.detectSingleFace(
      video,
      new faceapi.TinyFaceDetectorOptions()
    );
    return detection || null;
  } catch (error) {
    console.error('Error detecting face:', error);
    return null;
  }
};

export const getFaceDescriptor = async (
  input: HTMLVideoElement | HTMLImageElement | HTMLCanvasElement
): Promise<Float32Array | null> => {
  if (!modelsLoaded) {
    await loadModels();
  }
  
  try {
    const detection = await faceapi
      .detectSingleFace(input, new faceapi.TinyFaceDetectorOptions())
      .withFaceLandmarks()
      .withFaceDescriptor();
    
    return detection ? detection.descriptor : null;
  } catch (error) {
    console.error('Error getting face descriptor:', error);
    return null;
  }
};

export const getFaceDescriptorFromImage = async (
  image: HTMLImageElement | HTMLCanvasElement
): Promise<Float32Array | null> => {
  return getFaceDescriptor(image);
};

export const compareFaces = (
  descriptor1: Float32Array,
  descriptor2: Float32Array,
  threshold: number = 0.6
): { match: boolean; distance: number } => {
  const distance = faceapi.euclideanDistance(descriptor1, descriptor2);
  return {
    match: distance < threshold,
    distance,
  };
};

export const findMatchingStudent = (
  queryDescriptor: Float32Array,
  students: Array<{ id: string; faceDescriptor?: Float32Array }>,
  threshold: number = 0.6
): { studentId: string; confidence: number } | null => {
  let bestMatch: { studentId: string; confidence: number } | null = null;
  let bestDistance = threshold;
  
  for (const student of students) {
    if (!student.faceDescriptor) continue;
    
    const { distance } = compareFaces(queryDescriptor, student.faceDescriptor);
    
    if (distance < bestDistance) {
      bestDistance = distance;
      bestMatch = {
        studentId: student.id,
        confidence: Math.round((1 - distance) * 100),
      };
    }
  }
  
  return bestMatch;
};

export const drawFaceDetection = (
  canvas: HTMLCanvasElement,
  video: HTMLVideoElement,
  detection: faceapi.FaceDetection
): void => {
  const displaySize = { width: video.videoWidth, height: video.videoHeight };
  faceapi.matchDimensions(canvas, displaySize);
  
  const resizedDetection = faceapi.resizeResults(detection, displaySize);
  
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw detection box
    const box = resizedDetection.box;
    ctx.strokeStyle = '#00ff88';
    ctx.lineWidth = 3;
    ctx.strokeRect(box.x, box.y, box.width, box.height);
    
    // Draw corner accents
    const cornerLength = 20;
    ctx.strokeStyle = '#00ff88';
    ctx.lineWidth = 4;
    
    // Top-left
    ctx.beginPath();
    ctx.moveTo(box.x, box.y + cornerLength);
    ctx.lineTo(box.x, box.y);
    ctx.lineTo(box.x + cornerLength, box.y);
    ctx.stroke();
    
    // Top-right
    ctx.beginPath();
    ctx.moveTo(box.x + box.width - cornerLength, box.y);
    ctx.lineTo(box.x + box.width, box.y);
    ctx.lineTo(box.x + box.width, box.y + cornerLength);
    ctx.stroke();
    
    // Bottom-left
    ctx.beginPath();
    ctx.moveTo(box.x, box.y + box.height - cornerLength);
    ctx.lineTo(box.x, box.y + box.height);
    ctx.lineTo(box.x + cornerLength, box.y + box.height);
    ctx.stroke();
    
    // Bottom-right
    ctx.beginPath();
    ctx.moveTo(box.x + box.width - cornerLength, box.y + box.height);
    ctx.lineTo(box.x + box.width, box.y + box.height);
    ctx.lineTo(box.x + box.width, box.y + box.height - cornerLength);
    ctx.stroke();
  }
};

export const captureFrame = (video: HTMLVideoElement): string => {
  const canvas = document.createElement('canvas');
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.drawImage(video, 0, 0);
  }
  return canvas.toDataURL('image/jpeg', 0.8);
};
