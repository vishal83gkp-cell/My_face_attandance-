// Local Storage utilities for data persistence

import { Student, Admin, Class, AttendanceRecord, User, Notification } from '../types';

const STORAGE_KEYS = {
  STUDENTS: 'attendance_students',
  ADMINS: 'attendance_admins',
  CLASSES: 'attendance_classes',
  ATTENDANCE: 'attendance_records',
  CURRENT_USER: 'attendance_current_user',
  NOTIFICATIONS: 'attendance_notifications',
  DARK_MODE: 'attendance_dark_mode',
};

// Generic storage functions
export const getFromStorage = <T>(key: string, defaultValue: T): T => {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch {
    return defaultValue;
  }
};

export const saveToStorage = <T>(key: string, value: T): void => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error('Error saving to storage:', error);
  }
};

// Students
export const getStudents = (): Student[] => 
  getFromStorage<Student[]>(STORAGE_KEYS.STUDENTS, []);

export const saveStudents = (students: Student[]): void => 
  saveToStorage(STORAGE_KEYS.STUDENTS, students);

export const addStudent = (student: Student): void => {
  const students = getStudents();
  students.push(student);
  saveStudents(students);
};

export const updateStudent = (id: string, updates: Partial<Student>): void => {
  const students = getStudents();
  const index = students.findIndex(s => s.id === id);
  if (index !== -1) {
    students[index] = { ...students[index], ...updates };
    saveStudents(students);
  }
};

export const deleteStudent = (id: string): void => {
  const students = getStudents().filter(s => s.id !== id);
  saveStudents(students);
};

// Admins
export const getAdmins = (): Admin[] => 
  getFromStorage<Admin[]>(STORAGE_KEYS.ADMINS, []);

export const saveAdmins = (admins: Admin[]): void => 
  saveToStorage(STORAGE_KEYS.ADMINS, admins);

export const addAdmin = (admin: Admin): void => {
  const admins = getAdmins();
  admins.push(admin);
  saveAdmins(admins);
};

// Classes
export const getClasses = (): Class[] => 
  getFromStorage<Class[]>(STORAGE_KEYS.CLASSES, []);

export const saveClasses = (classes: Class[]): void => 
  saveToStorage(STORAGE_KEYS.CLASSES, classes);

export const addClass = (classItem: Class): void => {
  const classes = getClasses();
  classes.push(classItem);
  saveClasses(classes);
};

export const updateClass = (id: string, updates: Partial<Class>): void => {
  const classes = getClasses();
  const index = classes.findIndex(c => c.id === id);
  if (index !== -1) {
    classes[index] = { ...classes[index], ...updates, updatedAt: new Date().toISOString() };
    saveClasses(classes);
  }
};

export const deleteClass = (id: string): void => {
  const classes = getClasses().filter(c => c.id !== id);
  saveClasses(classes);
};

// Attendance
export const getAttendance = (): AttendanceRecord[] => 
  getFromStorage<AttendanceRecord[]>(STORAGE_KEYS.ATTENDANCE, []);

export const saveAttendance = (attendance: AttendanceRecord[]): void => 
  saveToStorage(STORAGE_KEYS.ATTENDANCE, attendance);

export const addAttendanceRecord = (record: AttendanceRecord): void => {
  const attendance = getAttendance();
  // Check for duplicate attendance for same student on same date
  const existing = attendance.find(
    a => a.studentId === record.studentId && a.date === record.date && a.classId === record.classId
  );
  if (!existing) {
    attendance.push(record);
    saveAttendance(attendance);
  }
};

// Current User
export const getCurrentUser = (): User | null => 
  getFromStorage<User | null>(STORAGE_KEYS.CURRENT_USER, null);

export const saveCurrentUser = (user: User | null): void => 
  saveToStorage(STORAGE_KEYS.CURRENT_USER, user);

// Notifications
export const getNotifications = (): Notification[] => 
  getFromStorage<Notification[]>(STORAGE_KEYS.NOTIFICATIONS, []);

export const saveNotifications = (notifications: Notification[]): void => 
  saveToStorage(STORAGE_KEYS.NOTIFICATIONS, notifications);

// Dark Mode
export const getDarkMode = (): boolean => 
  getFromStorage<boolean>(STORAGE_KEYS.DARK_MODE, false);

export const saveDarkMode = (darkMode: boolean): void => 
  saveToStorage(STORAGE_KEYS.DARK_MODE, darkMode);

// Initialize with demo data
export const initializeDemoData = (): void => {
  // Check if already initialized
  if (getClasses().length > 0) return;

  // Demo Classes
  const demoClasses: Class[] = [
    {
      id: 'class-1',
      name: 'Computer Science',
      section: 'A',
      subject: 'Data Structures',
      academicYear: '2024-2025',
      studentCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'class-2',
      name: 'Computer Science',
      section: 'B',
      subject: 'Algorithms',
      academicYear: '2024-2025',
      studentCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
    {
      id: 'class-3',
      name: 'Information Technology',
      section: 'A',
      subject: 'Web Development',
      academicYear: '2024-2025',
      studentCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    },
  ];
  saveClasses(demoClasses);

  // Demo Admin
  const demoAdmin: Admin = {
    id: 'admin-1',
    email: 'admin@school.edu',
    name: 'Dr. Sarah Johnson',
    role: 'admin',
    employeeId: 'EMP001',
    department: 'Computer Science',
    createdAt: new Date().toISOString(),
  };
  const admins = getAdmins();
  if (!admins.find(a => a.email === demoAdmin.email)) {
    admins.push(demoAdmin);
    saveAdmins(admins);
  }

  // Demo Students
  const demoStudents: Student[] = [
    {
      id: 'student-1',
      email: 'john@student.edu',
      name: 'John Smith',
      role: 'student',
      rollNo: 'CS001',
      classId: 'class-1',
      age: 20,
      createdAt: new Date().toISOString(),
    },
    {
      id: 'student-2',
      email: 'emma@student.edu',
      name: 'Emma Wilson',
      role: 'student',
      rollNo: 'CS002',
      classId: 'class-1',
      age: 19,
      createdAt: new Date().toISOString(),
    },
    {
      id: 'student-3',
      email: 'michael@student.edu',
      name: 'Michael Brown',
      role: 'student',
      rollNo: 'CS003',
      classId: 'class-2',
      age: 21,
      createdAt: new Date().toISOString(),
    },
    {
      id: 'student-4',
      email: 'sarah@student.edu',
      name: 'Sarah Davis',
      role: 'student',
      rollNo: 'CS004',
      classId: 'class-2',
      age: 20,
      createdAt: new Date().toISOString(),
    },
    {
      id: 'student-5',
      email: 'david@student.edu',
      name: 'David Lee',
      role: 'student',
      rollNo: 'IT001',
      classId: 'class-3',
      age: 22,
      createdAt: new Date().toISOString(),
    },
  ];
  saveStudents(demoStudents);

  // Update class student counts
  demoClasses.forEach(c => {
    c.studentCount = demoStudents.filter(s => s.classId === c.id).length;
  });
  saveClasses(demoClasses);
};
