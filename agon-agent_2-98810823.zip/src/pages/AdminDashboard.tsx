import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { 
  Users, 
  GraduationCap, 
  Calendar, 
  TrendingUp, 
  Camera,
  ArrowRight,
  Clock,
  CheckCircle,
  XCircle,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { StatsCard } from '../components/StatsCard';
import { AttendanceBarChart, AttendancePieChart } from '../components/Charts';
import { format, subDays } from 'date-fns';

export const AdminDashboard: React.FC = () => {
  const { students, classes, attendance, getStats } = useApp();
  const stats = getStats();

  // Prepare chart data
  const weeklyData = useMemo(() => {
    const data = [];
    for (let i = 6; i >= 0; i--) {
      const date = format(subDays(new Date(), i), 'yyyy-MM-dd');
      const dayAttendance = attendance.filter(a => a.date === date);
      const present = dayAttendance.filter(a => a.status === 'present' || a.status === 'late').length;
      const absent = students.length - present;
      data.push({
        name: format(subDays(new Date(), i), 'EEE'),
        present: Math.max(0, present),
        absent: Math.max(0, absent),
      });
    }
    return data;
  }, [attendance, students]);

  const pieData = useMemo(() => [
    { name: 'Present', value: stats.todayAttendance, color: '#22c55e' },
    { name: 'Absent', value: Math.max(0, stats.totalStudents - stats.todayAttendance), color: '#ef4444' },
  ], [stats]);

  const recentAttendance = useMemo(() => {
    return attendance
      .filter(a => {
        const today = new Date();
        const recordDate = new Date(a.date);
        return recordDate >= subDays(today, 1);
      })
      .slice(-5)
      .reverse();
  }, [attendance]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Dashboard</h1>
          <p className="text-slate-400">Welcome back! Here's your attendance overview.</p>
        </div>
        <Link
          to="/attendance"
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-xl font-medium shadow-lg shadow-blue-500/25 hover:shadow-blue-500/40 transition-all"
        >
          <Camera className="w-5 h-5" />
          Take Attendance
        </Link>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          title="Total Students"
          value={stats.totalStudents}
          subtitle="Enrolled students"
          icon={Users}
          color="blue"
        />
        <StatsCard
          title="Total Classes"
          value={stats.totalClasses}
          subtitle="Active classes"
          icon={GraduationCap}
          color="purple"
        />
        <StatsCard
          title="Present Today"
          value={stats.todayAttendance}
          subtitle={`${stats.todayPercentage}% attendance`}
          icon={CheckCircle}
          color="green"
        />
        <StatsCard
          title="Weekly Average"
          value={`${stats.weeklyAttendance}`}
          subtitle="Total check-ins"
          icon={TrendingUp}
          color="orange"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Attendance Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6"
        >
          <h3 className="text-lg font-semibold text-white mb-4">Weekly Attendance</h3>
          <AttendanceBarChart data={weeklyData} />
        </motion.div>

        {/* Today's Overview */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6"
        >
          <h3 className="text-lg font-semibold text-white mb-4">Today's Overview</h3>
          <AttendancePieChart data={pieData} />
        </motion.div>
      </div>

      {/* Recent Activity & Classes */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Attendance */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-white">Recent Activity</h3>
            <Link to="/reports" className="text-sm text-blue-400 hover:text-blue-300 flex items-center gap-1">
              View all <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          
          {recentAttendance.length === 0 ? (
            <div className="text-center py-8 text-slate-500">
              <Clock className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>No recent attendance records</p>
            </div>
          ) : (
            <div className="space-y-3">
              {recentAttendance.map((record) => (
                <div
                  key={record.id}
                  className="flex items-center gap-3 p-3 bg-slate-800/50 rounded-xl"
                >
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    record.status === 'present' ? 'bg-green-500/20' : 'bg-red-500/20'
                  }`}>
                    {record.status === 'present' ? (
                      <CheckCircle className="w-5 h-5 text-green-400" />
                    ) : (
                      <XCircle className="w-5 h-5 text-red-400" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate">{record.studentName}</p>
                    <p className="text-xs text-slate-400">{record.className}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-slate-400">{record.time}</p>
                    <p className="text-xs text-slate-500">{record.method === 'face' ? 'Face ID' : 'Manual'}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6"
        >
          <h3 className="text-lg font-semibold text-white mb-4">Classes Overview</h3>
          
          {classes.length === 0 ? (
            <div className="text-center py-8 text-slate-500">
              <GraduationCap className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>No classes created yet</p>
              <Link to="/classes" className="text-sm text-blue-400 hover:text-blue-300 mt-2 inline-block">
                Create your first class
              </Link>
            </div>
          ) : (
            <div className="space-y-3">
              {classes.slice(0, 4).map((cls) => (
                <div
                  key={cls.id}
                  className="flex items-center gap-3 p-3 bg-slate-800/50 rounded-xl"
                >
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                    <GraduationCap className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-white truncate">{cls.name} - {cls.section}</p>
                    <p className="text-xs text-slate-400">{cls.subject}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-white">{cls.studentCount}</p>
                    <p className="text-xs text-slate-500">students</p>
                  </div>
                </div>
              ))}
            </div>
          )}
          
          <Link
            to="/classes"
            className="flex items-center justify-center gap-2 w-full mt-4 py-2 border border-slate-700 text-slate-400 rounded-xl text-sm hover:bg-slate-800/50 hover:text-white transition-all"
          >
            Manage Classes <ArrowRight className="w-4 h-4" />
          </Link>
        </motion.div>
      </div>
    </div>
  );
};
