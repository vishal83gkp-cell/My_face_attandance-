import React, { useState, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Camera, Users, CheckCircle, XCircle, Clock, UserCheck, AlertCircle, RefreshCw, UserPlus } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { FaceDetector } from '../components/FaceDetector';
import { getDateKey } from '../lib/utils';

export const AttendancePage: React.FC = () => {
  const { students, classes, attendance, markAttendance, updateStudent, addNotification, getTodayAttendance } = useApp();
  const [selectedClass, setSelectedClass] = useState<string>('');
  const [markedStudents, setMarkedStudents] = useState<Set<string>>(new Set());
  const [pendingFaceData, setPendingFaceData] = useState<{
    photo: string;
    descriptor: Float32Array;
  } | null>(null);
  const [showStudentSelector, setShowStudentSelector] = useState(false);

  const today = getDateKey();
  const todayAttendance = getTodayAttendance(selectedClass);
  
  // Get students for selected class
  const classStudents = useMemo(() => {
    if (!selectedClass) return [];
    return students.filter(s => s.classId === selectedClass);
  }, [students, selectedClass]);

  // Students with face data registered
  const studentsWithFaceData = useMemo(() => {
    return classStudents.filter(s => s.faceDescriptor);
  }, [classStudents]);

  // Students without face data
  const studentsWithoutFaceData = useMemo(() => {
    return classStudents.filter(s => !s.faceDescriptor);
  }, [classStudents]);

  // Get class info
  const selectedClassInfo = useMemo(() => {
    return classes.find(c => c.id === selectedClass);
  }, [classes, selectedClass]);

  // Handle face recognition match
  const handleFaceMatch = useCallback((studentId: string, confidence: number, photo: string) => {
    const student = students.find(s => s.id === studentId);
    if (!student) return;

    // Check if already marked today
    if (markedStudents.has(studentId)) {
      addNotification('warning', `${student.name} is already marked present today`);
      return;
    }

    // Mark attendance
    markAttendance({
      studentId: student.id,
      studentName: student.name,
      rollNo: student.rollNo,
      classId: student.classId,
      className: `${selectedClassInfo?.name || ''} - ${selectedClassInfo?.section || ''}`,
      date: today,
      time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      status: 'present',
      method: 'face',
      confidence,
    });

    setMarkedStudents(prev => new Set(prev).add(studentId));
    addNotification('success', `✅ Attendance marked for ${student.name}`);
    setPendingFaceData(null);
    setShowStudentSelector(false);
  }, [students, selectedClassInfo, today, markAttendance, addNotification, markedStudents]);

  // Handle no match - show student selector
  const handleNoMatch = useCallback((photo: string, descriptor?: Float32Array) => {
    if (descriptor) {
      setPendingFaceData({ photo, descriptor });
      setShowStudentSelector(true);
    }
  }, []);

  // Register face and mark attendance for selected student
  const handleRegisterAndMarkAttendance = useCallback((studentId: string) => {
    if (!pendingFaceData) return;

    const student = students.find(s => s.id === studentId);
    if (!student) return;

    // Register face
    updateStudent(studentId, {
      photo: pendingFaceData.photo,
      faceDescriptor: pendingFaceData.descriptor,
    });

    // Mark attendance
    markAttendance({
      studentId: student.id,
      studentName: student.name,
      rollNo: student.rollNo,
      classId: student.classId,
      className: `${selectedClassInfo?.name || ''} - ${selectedClassInfo?.section || ''}`,
      date: today,
      time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      status: 'present',
      method: 'face',
      confidence: 100,
    });

    setMarkedStudents(prev => new Set(prev).add(studentId));
    addNotification('success', `✅ Face registered & attendance marked for ${student.name}`);
    setPendingFaceData(null);
    setShowStudentSelector(false);
  }, [pendingFaceData, students, selectedClassInfo, today, markAttendance, updateStudent, addNotification]);

  // Handle manual attendance
  const handleManualAttendance = useCallback((studentId: string, status: 'present' | 'absent' | 'late' = 'present') => {
    const student = students.find(s => s.id === studentId);
    if (!student) return;

    // Check if already marked today
    if (markedStudents.has(studentId)) {
      addNotification('warning', `${student.name} is already marked today`);
      return;
    }

    markAttendance({
      studentId: student.id,
      studentName: student.name,
      rollNo: student.rollNo,
      classId: student.classId,
      className: `${selectedClassInfo?.name || ''} - ${selectedClassInfo?.section || ''}`,
      date: today,
      time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      status,
      method: 'manual',
    });

    setMarkedStudents(prev => new Set(prev).add(studentId));
    addNotification('success', `✅ Attendance marked for ${student.name}`);
  }, [students, selectedClassInfo, today, markAttendance, addNotification, markedStudents]);

  // Mark all absent for unmarked students
  const markRemainingAbsent = useCallback(() => {
    let count = 0;
    classStudents.forEach(student => {
      if (!markedStudents.has(student.id)) {
        markAttendance({
          studentId: student.id,
          studentName: student.name,
          rollNo: student.rollNo,
          classId: student.classId,
          className: `${selectedClassInfo?.name || ''} - ${selectedClassInfo?.section || ''}`,
          date: today,
          time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
          status: 'absent',
          method: 'manual',
        });
        count++;
      }
    });
    addNotification('success', `${count} students marked as absent`);
  }, [classStudents, markedStudents, selectedClassInfo, today, markAttendance, addNotification]);

  // Stats
  const stats = useMemo(() => ({
    total: classStudents.length,
    present: markedStudents.size,
    absent: classStudents.length - markedStudents.size,
    withFaceData: studentsWithFaceData.length,
  }), [classStudents, markedStudents, studentsWithFaceData]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Take Attendance</h1>
          <p className="text-slate-400">Use face recognition or manual entry</p>
        </div>
        <div className="flex items-center gap-3">
          <select
            value={selectedClass}
            onChange={(e) => {
              setSelectedClass(e.target.value);
              setMarkedStudents(new Set());
              setPendingFaceData(null);
              setShowStudentSelector(false);
            }}
            className="px-4 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-blue-500/50"
          >
            <option value="">Select Class</option>
            {classes.map(cls => (
              <option key={cls.id} value={cls.id}>{cls.name} - {cls.section}</option>
            ))}
          </select>
        </div>
      </div>

      {!selectedClass ? (
        <div className="text-center py-16">
          <Camera className="w-16 h-16 mx-auto mb-4 text-slate-600" />
          <p className="text-slate-400">Select a class to start taking attendance</p>
        </div>
      ) : (
        <>
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-4">
              <p className="text-sm text-slate-400">Total Students</p>
              <p className="text-2xl font-bold text-white">{stats.total}</p>
            </div>
            <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-4">
              <p className="text-sm text-green-400">Present</p>
              <p className="text-2xl font-bold text-green-400">{stats.present}</p>
            </div>
            <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4">
              <p className="text-sm text-red-400">Absent</p>
              <p className="text-2xl font-bold text-red-400">{stats.absent}</p>
            </div>
            <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-4">
              <p className="text-sm text-blue-400">Face Registered</p>
              <p className="text-2xl font-bold text-blue-400">{stats.withFaceData}/{stats.total}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Face Recognition Section */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-white">Face Recognition</h3>
                <div className="flex items-center gap-2 text-sm text-slate-400">
                  <Camera className="w-4 h-4" />
                  AI-Powered
                </div>
              </div>
              
              <FaceDetector
                students={classStudents}
                onMatch={handleFaceMatch}
                onNoMatch={handleNoMatch}
                mode="attendance"
              />

              {/* Student Selector for Unrecognized Faces */}
              <AnimatePresence>
                {showStudentSelector && pendingFaceData && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mt-4 p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-xl"
                  >
                    <div className="flex items-center gap-2 mb-3">
                      <UserPlus className="w-5 h-5 text-yellow-400" />
                      <p className="text-yellow-400 font-medium">Face Not Recognized</p>
                    </div>
                    <p className="text-sm text-slate-300 mb-4">
                      Select a student to register their face and mark attendance:
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto">
                      {studentsWithoutFaceData.map(student => (
                        <button
                          key={student.id}
                          onClick={() => handleRegisterAndMarkAttendance(student.id)}
                          className="flex items-center gap-2 p-2 bg-slate-800/50 hover:bg-slate-700 rounded-lg transition-colors text-left"
                        >
                          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-sm font-medium">
                            {student.name.charAt(0)}
                          </div>
                          <div>
                            <p className="text-sm text-white">{student.name}</p>
                            <p className="text-xs text-slate-400">{student.rollNo}</p>
                          </div>
                        </button>
                      ))}
                    </div>
                    {studentsWithoutFaceData.length === 0 && (
                      <p className="text-sm text-slate-400">All students already have face data registered.</p>
                    )}
                    <button
                      onClick={() => {
                        setShowStudentSelector(false);
                        setPendingFaceData(null);
                      }}
                      className="mt-3 text-sm text-slate-400 hover:text-white transition-colors"
                    >
                      Cancel
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>

            {/* Student List & Manual Entry */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-white">Student List</h3>
                <button
                  onClick={markRemainingAbsent}
                  className="text-sm text-red-400 hover:text-red-300 transition-colors"
                >
                  Mark Remaining Absent
                </button>
              </div>
              
              <div className="space-y-2 max-h-[400px] overflow-y-auto">
                {classStudents.map(student => {
                  const isMarked = markedStudents.has(student.id);
                  const hasFaceData = !!student.faceDescriptor;
                  
                  return (
                    <motion.div
                      key={student.id}
                      layout
                      className={`flex items-center gap-3 p-3 rounded-xl transition-colors ${
                        isMarked ? 'bg-green-500/10 border border-green-500/20' : 'bg-slate-800/50'
                      }`}
                    >
                      <div className="relative">
                        {student.photo ? (
                          <img
                            src={student.photo}
                            alt={student.name}
                            className="w-10 h-10 rounded-lg object-cover"
                          />
                        ) : (
                          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                            <span className="text-sm font-bold text-white">
                              {student.name.charAt(0)}
                            </span>
                          </div>
                        )}
                        {hasFaceData && (
                          <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full flex items-center justify-center">
                            <CheckCircle className="w-2.5 h-2.5 text-white" />
                          </div>
                        )}
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-white truncate">{student.name}</p>
                        <p className="text-xs text-slate-400">{student.rollNo}</p>
                      </div>
                      
                      {isMarked ? (
                        <div className="flex items-center gap-2 text-green-400">
                          <CheckCircle className="w-5 h-5" />
                          <span className="text-sm">Present</span>
                        </div>
                      ) : (
                        <button
                          onClick={() => handleManualAttendance(student.id)}
                          className="flex items-center gap-2 px-3 py-1.5 bg-blue-500/10 text-blue-400 rounded-lg hover:bg-blue-500/20 transition-colors"
                        >
                          <UserCheck className="w-4 h-4" />
                          Mark
                        </button>
                      )}
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          </div>

          {/* Today's Attendance Summary */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6"
          >
            <h3 className="text-lg font-semibold text-white mb-4">Today's Attendance</h3>
            
            {todayAttendance.length === 0 ? (
              <div className="text-center py-8 text-slate-500">
                <Clock className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>No attendance records for today yet</p>
                <p className="text-sm mt-2">Use face recognition or click Mark button</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {todayAttendance.map(record => (
                  <motion.div
                    key={record.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className={`p-3 rounded-xl border ${
                      record.status === 'present' 
                        ? 'bg-green-500/10 border-green-500/20' 
                        : record.status === 'late'
                        ? 'bg-yellow-500/10 border-yellow-500/20'
                        : 'bg-red-500/10 border-red-500/20'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      {record.status === 'present' ? (
                        <CheckCircle className="w-4 h-4 text-green-400" />
                      ) : record.status === 'late' ? (
                        <Clock className="w-4 h-4 text-yellow-400" />
                      ) : (
                        <XCircle className="w-4 h-4 text-red-400" />
                      )}
                      <span className="text-sm font-medium text-white">{record.studentName}</span>
                    </div>
                    <div className="mt-2 text-xs text-slate-400">
                      {record.time} • {record.method === 'face' ? '🤖 Face ID' : '👆 Manual'}
                      {record.confidence && <span className="ml-1">({record.confidence}%)</span>}
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </motion.div>
        </>
      )}
    </div>
  );
};
