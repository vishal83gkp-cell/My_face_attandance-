import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import { Calendar, Clock, CheckCircle, XCircle, FileText } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useApp } from '../context/AppContext';
import { DataTable } from '../components/DataTable';
import { format } from 'date-fns';

export const MyAttendancePage: React.FC = () => {
  const { user } = useAuth();
  const { attendance, classes } = useApp();

  // Get student's attendance records
  const studentAttendance = useMemo(() => {
    if (!user) return [];
    return attendance
      .filter(a => a.studentId === user.id)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [attendance, user]);

  // Calculate stats
  const stats = useMemo(() => {
    const total = studentAttendance.length;
    const present = studentAttendance.filter(a => a.status === 'present').length;
    const late = studentAttendance.filter(a => a.status === 'late').length;
    const absent = studentAttendance.filter(a => a.status === 'absent').length;
    
    return {
      total,
      present,
      late,
      absent,
      percentage: total > 0 ? Math.round(((present + late) / total) * 100) : 0,
    };
  }, [studentAttendance]);

  // Table columns
  const columns = [
    { 
      key: 'date', 
      header: 'Date', 
      sortable: true, 
      render: (item: typeof studentAttendance[0]) => format(new Date(item.date), 'MMM dd, yyyy') 
    },
    { key: 'className', header: 'Class' },
    { 
      key: 'status', 
      header: 'Status', 
      render: (item: typeof studentAttendance[0]) => (
        <span className={`flex items-center gap-2 px-3 py-1 rounded-lg text-sm font-medium ${
          item.status === 'present' ? 'bg-green-500/10 text-green-400' :
          item.status === 'late' ? 'bg-yellow-500/10 text-yellow-400' :
          'bg-red-500/10 text-red-400'
        }`}>
          {item.status === 'present' && <CheckCircle className="w-4 h-4" />}
          {item.status === 'late' && <Clock className="w-4 h-4" />}
          {item.status === 'absent' && <XCircle className="w-4 h-4" />}
          {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
        </span>
      )
    },
    { key: 'time', header: 'Time' },
    { 
      key: 'method', 
      header: 'Method', 
      render: (item: typeof studentAttendance[0]) => (
        <span className="text-slate-400">
          {item.method === 'face' ? 'Face Recognition' : 'Manual'}
        </span>
      )
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">My Attendance</h1>
        <p className="text-slate-400">View your attendance history</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-4">
          <p className="text-sm text-slate-400">Total Records</p>
          <p className="text-2xl font-bold text-white">{stats.total}</p>
        </div>
        <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-4">
          <p className="text-sm text-green-400">Present</p>
          <p className="text-2xl font-bold text-green-400">{stats.present}</p>
        </div>
        <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-4">
          <p className="text-sm text-yellow-400">Late</p>
          <p className="text-2xl font-bold text-yellow-400">{stats.late}</p>
        </div>
        <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4">
          <p className="text-sm text-red-400">Absent</p>
          <p className="text-2xl font-bold text-red-400">{stats.absent}</p>
        </div>
      </div>

      {/* Attendance Rate */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6"
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-white">Overall Attendance Rate</h3>
          <span className={`text-2xl font-bold ${
            stats.percentage >= 75 ? 'text-green-400' :
            stats.percentage >= 50 ? 'text-yellow-400' : 'text-red-400'
          }`}>
            {stats.percentage}%
          </span>
        </div>
        <div className="h-3 bg-slate-800 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${stats.percentage}%` }}
            transition={{ duration: 1 }}
            className={`h-full rounded-full ${
              stats.percentage >= 75 ? 'bg-gradient-to-r from-green-500 to-emerald-500' :
              stats.percentage >= 50 ? 'bg-gradient-to-r from-yellow-500 to-orange-500' :
              'bg-gradient-to-r from-red-500 to-pink-500'
            }`}
          />
        </div>
      </motion.div>

      {/* Attendance Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6"
      >
        <div className="flex items-center gap-2 mb-4">
          <FileText className="w-5 h-5 text-blue-400" />
          <h3 className="text-lg font-semibold text-white">Attendance History</h3>
        </div>
        <DataTable
          data={studentAttendance}
          columns={columns}
          searchPlaceholder="Search records..."
          emptyMessage="No attendance records found"
        />
      </motion.div>
    </div>
  );
};
