import React, { useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { User, Camera, Mail, Phone, MapPin, Calendar, Edit2, Save } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useApp } from '../context/AppContext';
import { WebcamCapture } from '../components/WebcamCapture';
import { Modal } from '../components/Modal';
import { getFaceDescriptor } from '../lib/faceRecognition';
import { format } from 'date-fns';

export const ProfilePage: React.FC = () => {
  const { user } = useAuth();
  const { students, updateStudent, classes, addNotification } = useApp();
  const [isEditing, setIsEditing] = useState(false);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: '',
    address: '',
  });

  // Get student info
  const studentInfo = students.find(s => s.id === user?.id);
  const classInfo = studentInfo ? classes.find(c => c.id === studentInfo.classId) : null;

  const handleSave = () => {
    if (user) {
      updateStudent(user.id, formData);
      addNotification('success', 'Profile updated successfully');
      setIsEditing(false);
    }
  };

  const handleCapture = useCallback(async (imageSrc: string) => {
    if (!user) return;
    
    updateStudent(user.id, { photo: imageSrc });
    setIsCameraOpen(false);
    
    // Extract face descriptor
    const img = new window.Image();
    img.src = imageSrc;
    img.onload = async () => {
      const descriptor = await getFaceDescriptor(img);
      if (descriptor) {
        updateStudent(user.id, { faceDescriptor: descriptor });
        addNotification('success', 'Face registered successfully');
      } else {
        addNotification('warning', 'No face detected. Please try again.');
      }
    };
  }, [user, updateStudent, addNotification]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">My Profile</h1>
        <p className="text-slate-400">Manage your account information</p>
      </div>

      {/* Profile Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-slate-900/50 border border-slate-800 rounded-2xl overflow-hidden"
      >
        {/* Cover */}
        <div className="h-32 bg-gradient-to-r from-blue-500 to-purple-600" />
        
        {/* Content */}
        <div className="px-6 pb-6">
          {/* Avatar */}
          <div className="relative -mt-16 mb-4">
            <div className="relative inline-block">
              {studentInfo?.photo ? (
                <img
                  src={studentInfo.photo}
                  alt={studentInfo.name}
                  className="w-24 h-24 rounded-2xl object-cover border-4 border-slate-900"
                />
              ) : (
                <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center border-4 border-slate-900">
                  <User className="w-10 h-10 text-white" />
                </div>
              )}
              {studentInfo?.faceDescriptor && (
                <div className="absolute -bottom-1 -right-1 w-8 h-8 bg-green-500 rounded-full flex items-center justify-center border-2 border-slate-900">
                  <Camera className="w-4 h-4 text-white" />
                </div>
              )}
            </div>
            <button
              onClick={() => setIsCameraOpen(true)}
              className="ml-4 p-2 bg-blue-500/10 text-blue-400 rounded-lg hover:bg-blue-500/20 transition-colors"
            >
              <Camera className="w-5 h-5" />
            </button>
          </div>

          {/* Name & Role */}
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-white">{user?.name}</h2>
            <p className="text-slate-400">Student • {studentInfo?.rollNo}</p>
          </div>

          {/* Info Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center gap-3 p-4 bg-slate-800/50 rounded-xl">
              <Mail className="w-5 h-5 text-slate-400" />
              <div>
                <p className="text-xs text-slate-500">Email</p>
                <p className="text-white">{user?.email}</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3 p-4 bg-slate-800/50 rounded-xl">
              <Calendar className="w-5 h-5 text-slate-400" />
              <div>
                <p className="text-xs text-slate-500">Class</p>
                <p className="text-white">{classInfo ? `${classInfo.name} - ${classInfo.section}` : 'Not assigned'}</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3 p-4 bg-slate-800/50 rounded-xl">
              <Phone className="w-5 h-5 text-slate-400" />
              <div>
                <p className="text-xs text-slate-500">Phone</p>
                <p className="text-white">{studentInfo?.phone || 'Not provided'}</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3 p-4 bg-slate-800/50 rounded-xl">
              <MapPin className="w-5 h-5 text-slate-400" />
              <div>
                <p className="text-xs text-slate-500">Address</p>
                <p className="text-white">{studentInfo?.address || 'Not provided'}</p>
              </div>
            </div>
          </div>

          {/* Face Registration Status */}
          <div className={`mt-6 p-4 rounded-xl ${
            studentInfo?.faceDescriptor 
              ? 'bg-green-500/10 border border-green-500/20' 
              : 'bg-yellow-500/10 border border-yellow-500/20'
          }`}>
            <div className="flex items-center gap-3">
              <Camera className={`w-5 h-5 ${
                studentInfo?.faceDescriptor ? 'text-green-400' : 'text-yellow-400'
              }`} />
              <div>
                <p className={`font-medium ${
                  studentInfo?.faceDescriptor ? 'text-green-400' : 'text-yellow-400'
                }`}>
                  {studentInfo?.faceDescriptor ? 'Face Registered' : 'Face Not Registered'}
                </p>
                <p className="text-sm text-slate-400">
                  {studentInfo?.faceDescriptor 
                    ? 'You can use face recognition for attendance' 
                    : 'Register your face to use face recognition'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Camera Modal */}
      <Modal
        isOpen={isCameraOpen}
        onClose={() => setIsCameraOpen(false)}
        title="Update Profile Photo"
        size="lg"
      >
        <WebcamCapture
          onCapture={handleCapture}
          onClose={() => setIsCameraOpen(false)}
        />
      </Modal>
    </div>
  );
};
