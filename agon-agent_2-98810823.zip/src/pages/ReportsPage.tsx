import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { FileText, Download, Calendar, Filter, Users, TrendingUp, PieChart } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { DataTable } from '../components/DataTable';
import { AttendanceBarChart, AttendancePieChart, AttendanceTrendChart } from '../components/Charts';
import { exportToPDF, exportToExcel, prepareAttendanceExportData } from '../lib/export';
import { format, subDays, startOfMonth, endOfMonth, eachDayOfInterval } from 'date-fns';
import { getDateKey } from '../lib/utils';

export const ReportsPage: React.FC = () => {
  const { students, classes, attendance } = useApp();
  const [selectedClass, setSelectedClass] = useState<string>('');
  const [selectedStudent, setSelectedStudent] = useState<string>('');
  const [dateRange, setDateRange] = useState<'today' | 'week' | 'month' | 'custom'>('today');
  const [customDate, setCustomDate] = useState<string>(getDateKey());

  // Filter attendance records
  const filteredAttendance = useMemo(() => {
    let records = [...attendance];
    
    // Filter by class
    if (selectedClass) {
      records = records.filter(r => r.classId === selectedClass);
    }
    
    // Filter by student
    if (selectedStudent) {
      records = records.filter(r => r.studentId === selectedStudent);
    }
    
    // Filter by date range
    const today = new Date();
    switch (dateRange) {
      case 'today':
        records = records.filter(r => r.date === getDateKey());
        break;
      case 'week':
        const weekAgo = subDays(today, 7);
        records = records.filter(r => new Date(r.date) >= weekAgo);
        break;
      case 'month':
        const monthAgo = subDays(today, 30);
        records = records.filter(r => new Date(r.date) >= monthAgo);
        break;
      case 'custom':
        records = records.filter(r => r.date === customDate);
        break;
    }
    
    return records.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [attendance, selectedClass, selectedStudent, dateRange, customDate]);

  // Calculate stats
  const stats = useMemo(() => {
    const total = filteredAttendance.length;
    const present = filteredAttendance.filter(r => r.status === 'present' || r.status === 'late').length;
    const absent = filteredAttendance.filter(r => r.status === 'absent').length;
    const late = filteredAttendance.filter(r => r.status === 'late').length;
    
    return {
      total,
      present,
      absent,
      late,
      percentage: total > 0 ? Math.round((present / total) * 100) : 0,
    };
  }, [filteredAttendance]);

  // Chart data
  const trendData = useMemo(() => {
    const data = [];
    const today = new Date();
    
    for (let i = 13; i >= 0; i--) {
      const date = subDays(today, i);
      const dateKey = getDateKey(date);
      const dayRecords = attendance.filter(r => r.date === dateKey);
      const present = dayRecords.filter(r => r.status === 'present' || r.status === 'late').length;
      const total = students.length || 1;
      
      data.push({
        date: format(date, 'MMM dd'),
        attendance: Math.round((present / total) * 100),
      });
    }
    
    return data;
  }, [attendance, students]);

  const pieData = useMemo(() => [
    { name: 'Present', value: stats.present, color: '#22c55e' },
    { name: 'Absent', value: stats.absent, color: '#ef4444' },
    { name: 'Late', value: stats.late, color: '#eab308' },
  ], [stats]);

  // Export functions
  const handleExportPDF = () => {
    const exportData = prepareAttendanceExportData(filteredAttendance, students, classes);
    const className = selectedClass 
      ? classes.find(c => c.id === selectedClass)?.name 
      : 'All Classes';
    exportToPDF(
      exportData,
      'Attendance Report',
      dateRange === 'custom' ? customDate : getDateKey(),
      className
    );
  };

  const handleExportExcel = () => {
    const exportData = prepareAttendanceExportData(filteredAttendance, students, classes);
    exportToExcel(exportData, `attendance_${getDateKey()}`);
  };

  // Table columns
  const columns = [
    { key: 'date', header: 'Date', sortable: true, render: (item: typeof filteredAttendance[0]) => format(new Date(item.date), 'MMM dd, yyyy') },
    { key: 'studentName', header: 'Student', sortable: true },
    { key: 'rollNo', header: 'Roll No', sortable: true },
    { key: 'className', header: 'Class' },
    { key: 'status', header: 'Status', render: (item: typeof filteredAttendance[0]) => (
      <span className={`px-2 py-1 rounded-lg text-xs font-medium ${
        item.status === 'present' ? 'bg-green-500/10 text-green-400' :
        item.status === 'late' ? 'bg-yellow-500/10 text-yellow-400' :
        'bg-red-500/10 text-red-400'
      }`}>
        {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
      </span>
    )},
    { key: 'time', header: 'Time' },
    { key: 'method', header: 'Method', render: (item: typeof filteredAttendance[0]) => (
      <span className="text-slate-400">
        {item.method === 'face' ? 'Face ID' : 'Manual'}
      </span>
    )},
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Reports</h1>
          <p className="text-slate-400">View and export attendance reports</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={handleExportPDF}
            className="flex items-center gap-2 px-4 py-2 bg-red-500/10 text-red-400 rounded-xl hover:bg-red-500/20 transition-colors"
          >
            <FileText className="w-4 h-4" />
            PDF
          </button>
          <button
            onClick={handleExportExcel}
            className="flex items-center gap-2 px-4 py-2 bg-green-500/10 text-green-400 rounded-xl hover:bg-green-500/20 transition-colors"
          >
            <Download className="w-4 h-4" />
            Excel
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-4">
        <div className="flex items-center gap-2">
          <Calendar className="w-5 h-5 text-slate-500" />
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value as typeof dateRange)}
            className="px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-blue-500/50"
          >
            <option value="today">Today</option>
            <option value="week">Last 7 Days</option>
            <option value="month">Last 30 Days</option>
            <option value="custom">Custom Date</option>
          </select>
        </div>
        
        {dateRange === 'custom' && (
          <input
            type="date"
            value={customDate}
            onChange={(e) => setCustomDate(e.target.value)}
            className="px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-blue-500/50"
          />
        )}
        
        <div className="flex items-center gap-2">
          <Users className="w-5 h-5 text-slate-500" />
          <select
            value={selectedClass}
            onChange={(e) => setSelectedClass(e.target.value)}
            className="px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-blue-500/50"
          >
            <option value="">All Classes</option>
            {classes.map(cls => (
              <option key={cls.id} value={cls.id}>{cls.name} - {cls.section}</option>
            ))}
          </select>
        </div>
        
        <select
          value={selectedStudent}
          onChange={(e) => setSelectedStudent(e.target.value)}
          className="px-3 py-2 bg-slate-800/50 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-blue-500/50"
        >
          <option value="">All Students</option>
          {students.map(student => (
            <option key={student.id} value={student.id}>{student.name}</option>
          ))}
        </select>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-4">
          <p className="text-sm text-slate-400">Total Records</p>
          <p className="text-2xl font-bold text-white">{stats.total}</p>
        </div>
        <div className="bg-green-500/10 border border-green-500/20 rounded-xl p-4">
          <p className="text-sm text-green-400">Present</p>
          <p className="text-2xl font-bold text-green-400">{stats.present}</p>
        </div>
        <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4">
          <p className="text-sm text-red-400">Absent</p>
          <p className="text-2xl font-bold text-red-400">{stats.absent}</p>
        </div>
        <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-4">
          <p className="text-sm text-yellow-400">Late</p>
          <p className="text-2xl font-bold text-yellow-400">{stats.late}</p>
        </div>
        <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-4">
          <p className="text-sm text-blue-400">Rate</p>
          <p className="text-2xl font-bold text-blue-400">{stats.percentage}%</p>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-5 h-5 text-blue-400" />
            <h3 className="text-lg font-semibold text-white">Attendance Trend</h3>
          </div>
          <AttendanceTrendChart data={trendData} />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <PieChart className="w-5 h-5 text-purple-400" />
            <h3 className="text-lg font-semibold text-white">Status Distribution</h3>
          </div>
          <AttendancePieChart data={pieData} />
        </motion.div>
      </div>

      {/* Data Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6"
      >
        <h3 className="text-lg font-semibold text-white mb-4">Attendance Records</h3>
        <DataTable
          data={filteredAttendance}
          columns={columns}
          searchPlaceholder="Search records..."
          emptyMessage="No attendance records found"
        />
      </motion.div>
    </div>
  );
};
