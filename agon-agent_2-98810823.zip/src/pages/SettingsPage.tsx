import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Moon, Sun, Bell, Lock, User, Globe, Shield, HelpCircle } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { useAuth } from '../context/AuthContext';

export const SettingsPage: React.FC = () => {
  const { darkMode, toggleDarkMode } = useApp();
  const { user } = useAuth();
  const [notifications, setNotifications] = useState(true);
  const [autoMark, setAutoMark] = useState(true);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-white">Settings</h1>
        <p className="text-slate-400">Manage your preferences</p>
      </div>

      {/* Settings Sections */}
      <div className="space-y-4">
        {/* Appearance */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6"
        >
          <h3 className="text-lg font-semibold text-white mb-4">Appearance</h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                {darkMode ? <Moon className="w-5 h-5 text-slate-400" /> : <Sun className="w-5 h-5 text-yellow-400" />}
                <div>
                  <p className="text-white">Dark Mode</p>
                  <p className="text-sm text-slate-400">Toggle dark theme</p>
                </div>
              </div>
              <button
                onClick={toggleDarkMode}
                className={`w-12 h-6 rounded-full transition-colors ${
                  darkMode ? 'bg-blue-500' : 'bg-slate-700'
                }`}
              >
                <div className={`w-5 h-5 bg-white rounded-full transition-transform ${
                  darkMode ? 'translate-x-6' : 'translate-x-0.5'
                }`} />
              </button>
            </div>
          </div>
        </motion.div>

        {/* Notifications */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6"
        >
          <h3 className="text-lg font-semibold text-white mb-4">Notifications</h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Bell className="w-5 h-5 text-slate-400" />
                <div>
                  <p className="text-white">Push Notifications</p>
                  <p className="text-sm text-slate-400">Receive attendance alerts</p>
                </div>
              </div>
              <button
                onClick={() => setNotifications(!notifications)}
                className={`w-12 h-6 rounded-full transition-colors ${
                  notifications ? 'bg-blue-500' : 'bg-slate-700'
                }`}
              >
                <div className={`w-5 h-5 bg-white rounded-full transition-transform ${
                  notifications ? 'translate-x-6' : 'translate-x-0.5'
                }`} />
              </button>
            </div>
          </div>
        </motion.div>

        {/* Attendance Settings (Admin only) */}
        {user?.role === 'admin' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6"
          >
            <h3 className="text-lg font-semibold text-white mb-4">Attendance Settings</h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">\n                  <Shield className="w-5 h-5 text-slate-400" />
                  <div>
                    <p className="text-white">Auto-mark Absent</p>
                    <p className="text-sm text-slate-400">Automatically mark absent for unmarked students</p>
                  </div>
                </div>
                <button
                  onClick={() => setAutoMark(!autoMark)}
                  className={`w-12 h-6 rounded-full transition-colors ${
                    autoMark ? 'bg-blue-500' : 'bg-slate-700'
                  }`}
                >
                  <div className={`w-5 h-5 bg-white rounded-full transition-transform ${
                    autoMark ? 'translate-x-6' : 'translate-x-0.5'
                  }`} />
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {/* Account */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6"
        >
          <h3 className="text-lg font-semibold text-white mb-4">Account</h3>
          
          <div className="space-y-4">
            <div className="flex items-center gap-3 p-3 bg-slate-800/50 rounded-xl">
              <User className="w-5 h-5 text-slate-400" />
              <div className="flex-1">
                <p className="text-sm text-slate-400">Logged in as</p>
                <p className="text-white">{user?.email}</p>
              </div>
              <span className="px-2 py-1 bg-blue-500/10 text-blue-400 rounded-lg text-sm capitalize">
                {user?.role}
              </span>
            </div>
            
            <button className="flex items-center gap-3 w-full p-3 bg-slate-800/50 rounded-xl hover:bg-slate-800 transition-colors">
              <Lock className="w-5 h-5 text-slate-400" />
              <span className="text-white">Change Password</span>
            </button>
          </div>
        </motion.div>

        {/* Help */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6"
        >
          <h3 className="text-lg font-semibold text-white mb-4">Help & Support</h3>
          
          <div className="space-y-3">
            <button className="flex items-center gap-3 w-full p-3 bg-slate-800/50 rounded-xl hover:bg-slate-800 transition-colors">
              <HelpCircle className="w-5 h-5 text-slate-400" />
              <span className="text-white">FAQ</span>
            </button>
            <button className="flex items-center gap-3 w-full p-3 bg-slate-800/50 rounded-xl hover:bg-slate-800 transition-colors">
              <Globe className="w-5 h-5 text-slate-400" />
              <span className="text-white">Contact Support</span>
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};
