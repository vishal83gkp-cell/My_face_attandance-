import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import { Calendar, Clock, CheckCircle, XCircle, TrendingUp, User } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useApp } from '../context/AppContext';
import { StatsCard } from '../components/StatsCard';
import { AttendanceTrendChart } from '../components/Charts';
import { format, subDays } from 'date-fns';
import { getDateKey } from '../lib/utils';

export const StudentDashboard: React.FC = () => {
  const { user } = useAuth();
  const { attendance, students, classes } = useApp();

  // Get student's attendance records
  const studentAttendance = useMemo(() => {
    if (!user) return [];
    return attendance.filter(a => a.studentId === user.id);
  }, [attendance, user]);

  // Get student info
  const studentInfo = useMemo(() => {
    return students.find(s => s.id === user?.id);
  }, [students, user]);

  // Get class info
  const classInfo = useMemo(() => {
    if (!studentInfo) return null;
    return classes.find(c => c.id === studentInfo.classId);
  }, [classes, studentInfo]);

  // Calculate stats
  const stats = useMemo(() => {
    const total = studentAttendance.length;
    const present = studentAttendance.filter(a => a.status === 'present').length;
    const late = studentAttendance.filter(a => a.status === 'late').length;
    const absent = studentAttendance.filter(a => a.status === 'absent').length;
    
    return {
      total,
      present,
      late,
      absent,
      percentage: total > 0 ? Math.round(((present + late) / total) * 100) : 0,
    };
  }, [studentAttendance]);

  // Trend data for chart
  const trendData = useMemo(() => {
    const data = [];
    const today = new Date();
    
    for (let i = 13; i >= 0; i--) {
      const date = subDays(today, i);
      const dateKey = getDateKey(date);
      const record = studentAttendance.find(a => a.date === dateKey);
      
      data.push({
        date: format(date, 'MMM dd'),
        attendance: record ? (record.status === 'present' || record.status === 'late' ? 100 : 0) : 0,
      });
    }
    
    return data;
  }, [studentAttendance]);

  // Recent attendance
  const recentAttendance = useMemo(() => {
    return studentAttendance.slice(-5).reverse();
  }, [studentAttendance]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">Welcome, {user?.name}</h1>
          <p className="text-slate-400">Here's your attendance overview</p>
        </div>
      </div>

      {/* Student Info Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-blue-500/10 to-purple-500/10 border border-blue-500/20 rounded-2xl p-6"
      >
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
            {studentInfo?.photo ? (
              <img src={studentInfo.photo} alt={studentInfo.name} className="w-full h-full rounded-xl object-cover" />
            ) : (
              <User className="w-8 h-8 text-white" />
            )}
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">{user?.name}</h2>
            <p className="text-slate-400">{studentInfo?.rollNo} • {classInfo ? `${classInfo.name} - ${classInfo.section}` : 'No Class'}</p>
          </div>
        </div>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatsCard
          title="Total Classes"
          value={stats.total}
          subtitle="Attended sessions"
          icon={Calendar}
          color="blue"
        />
        <StatsCard
          title="Present"
          value={stats.present}
          subtitle="On time"
          icon={CheckCircle}
          color="green"
        />
        <StatsCard
          title="Late"
          value={stats.late}
          subtitle="Late arrivals"
          icon={Clock}
          color="orange"
        />
        <StatsCard
          title="Absent"
          value={stats.absent}
          subtitle="Missed classes"
          icon={XCircle}
          color="pink"
        />
      </div>

      {/* Attendance Rate */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6"
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-white">Attendance Rate</h3>
          <span className={`text-2xl font-bold ${
            stats.percentage >= 75 ? 'text-green-400' :
            stats.percentage >= 50 ? 'text-yellow-400' : 'text-red-400'
          }`}>
            {stats.percentage}%
          </span>
        </div>
        <div className="h-3 bg-slate-800 rounded-full overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${stats.percentage}%` }}
            transition={{ duration: 1, delay: 0.3 }}
            className={`h-full rounded-full ${
              stats.percentage >= 75 ? 'bg-gradient-to-r from-green-500 to-emerald-500' :
              stats.percentage >= 50 ? 'bg-gradient-to-r from-yellow-500 to-orange-500' :
              'bg-gradient-to-r from-red-500 to-pink-500'
            }`}
          />
        </div>
        <p className="text-sm text-slate-400 mt-2">
          {stats.percentage >= 75 ? 'Great! Keep up the good work!' :
           stats.percentage >= 50 ? 'Try to improve your attendance' :
           'Warning: Your attendance is below required level'}
        </p>
      </motion.div>

      {/* Charts & Recent */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Trend Chart */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6"
        >
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-5 h-5 text-blue-400" />
            <h3 className="text-lg font-semibold text-white">Attendance Trend</h3>
          </div>
          <AttendanceTrendChart data={trendData} />
        </motion.div>

        {/* Recent Activity */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6"
        >
          <h3 className="text-lg font-semibold text-white mb-4">Recent Activity</h3>
          
          {recentAttendance.length === 0 ? (
            <div className="text-center py-8 text-slate-500">
              <Calendar className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>No attendance records yet</p>
            </div>
          ) : (
            <div className="space-y-3">
              {recentAttendance.map(record => (
                <div
                  key={record.id}
                  className={`flex items-center gap-3 p-3 rounded-xl ${
                    record.status === 'present' ? 'bg-green-500/10' :
                    record.status === 'late' ? 'bg-yellow-500/10' :
                    'bg-red-500/10'
                  }`}
                >
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    record.status === 'present' ? 'bg-green-500/20' :
                    record.status === 'late' ? 'bg-yellow-500/20' :
                    'bg-red-500/20'
                  }`}>
                    {record.status === 'present' ? (
                      <CheckCircle className="w-5 h-5 text-green-400" />
                    ) : record.status === 'late' ? (
                      <Clock className="w-5 h-5 text-yellow-400" />
                    ) : (
                      <XCircle className="w-5 h-5 text-red-400" />
                    )}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-white capitalize">{record.status}</p>
                    <p className="text-xs text-slate-400">{record.className}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-slate-300">{format(new Date(record.date), 'MMM dd')}</p>
                    <p className="text-xs text-slate-500">{record.time}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
};
