// Type definitions for the Face Recognition Attendance System

export type UserRole = 'admin' | 'student';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  createdAt: string;
}

export interface Student extends User {
  role: 'student';
  rollNo: string;
  classId: string;
  age: number;
  faceDescriptor?: Float32Array;
  photo?: string;
  phone?: string;
  address?: string;
}

export interface Admin extends User {
  role: 'admin';
  employeeId: string;
  department?: string;
}

export interface Class {
  id: string;
  name: string;
  section: string;
  subject: string;
  academicYear: string;
  studentCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  studentName: string;
  rollNo: string;
  classId: string;
  className: string;
  date: string;
  time: string;
  status: 'present' | 'absent' | 'late';
  method: 'face' | 'manual';
  confidence?: number;
}

export interface AttendanceStats {
  totalStudents: number;
  presentToday: number;
  absentToday: number;
  attendancePercentage: number;
}

export interface Notification {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  message: string;
  timestamp: string;
}

export interface AppState {
  user: User | null;
  isAuthenticated: boolean;
  students: Student[];
  admins: Admin[];
  classes: Class[];
  attendance: AttendanceRecord[];
  notifications: Notification[];
  darkMode: boolean;
}

export interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string, role: UserRole) => Promise<boolean>;
  signup: (data: SignupData) => Promise<boolean>;
  logout: () => void;
}

export interface SignupData {
  email: string;
  password: string;
  name: string;
  role: UserRole;
  rollNo?: string;
  classId?: string;
  age?: number;
  employeeId?: string;
}
