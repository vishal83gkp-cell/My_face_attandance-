declare module 'jspdf-autotable' {
  import { jsPDF } from 'jspdf';
  
  interface AutoTableOptions {
    startY?: number;
    head?: Array<Array<string | number>>;
    body?: Array<Array<string | number>>;
    theme?: 'striped' | 'grid' | 'plain';
    headStyles?: {
      fillColor?: number[];
      textColor?: number[];
      fontStyle?: string;
    };
    alternateRowStyles?: {
      fillColor?: number[];
    };
    styles?: {
      fontSize?: number;
      cellPadding?: number;
    };
    columnStyles?: Record<number, { cellWidth?: number }>;
  }
  
  interface AutoTableResult {
    finalY: number;
  }
  
  function autoTable(doc: jsPDF, options: AutoTableOptions): AutoTableResult;
  
  export default autoTable;
}
